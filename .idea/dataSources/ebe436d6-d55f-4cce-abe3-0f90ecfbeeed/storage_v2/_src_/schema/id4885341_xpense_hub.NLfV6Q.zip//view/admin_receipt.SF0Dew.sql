create view admin_receipt as
  select
    `id4885341_xpense_hub`.`expense`.`expense_id`   AS `expense_id`,
    `id4885341_xpense_hub`.`expense`.`name`         AS `name`,
    `id4885341_xpense_hub`.`expense`.`price`        AS `price`,
    `id4885341_xpense_hub`.`expense`.`description`  AS `description`,
    `id4885341_xpense_hub`.`expense`.`user_id`      AS `user_id`,
    `id4885341_xpense_hub`.`expense`.`team_id`      AS `team_id`,
    `id4885341_xpense_hub`.`receipts`.`receipt_id`  AS `receipt_id`,
    `id4885341_xpense_hub`.`receipts`.`image_path`  AS `image_path`,
    `id4885341_xpense_hub`.`receipts`.`date_posted` AS `date_posted`,
    `user_team`.`full_name`                         AS `full_name`,
    `user_team`.`team_name`                         AS `team_name`
  from ((`id4885341_xpense_hub`.`expense`
    join `id4885341_xpense_hub`.`receipts`) join `id4885341_xpense_hub`.`user_team`
      on (((`id4885341_xpense_hub`.`expense`.`expense_id` = `id4885341_xpense_hub`.`receipts`.`expense_id`) and
           (`id4885341_xpense_hub`.`receipts`.`team_id` = `id4885341_xpense_hub`.`expense`.`team_id`))));

