create view user_team as
  select
    `id4885341_xpense_hub`.`users`.`user_id`      AS `user_id`,
    `id4885341_xpense_hub`.`users`.`team_id`      AS `team_id`,
    `id4885341_xpense_hub`.`users`.`full_name`    AS `full_name`,
    `id4885341_xpense_hub`.`users`.`email`        AS `email`,
    `id4885341_xpense_hub`.`users`.`password`     AS `password`,
    `id4885341_xpense_hub`.`users`.`image_path`   AS `image_path`,
    `id4885341_xpense_hub`.`users`.`type`         AS `type`,
    `id4885341_xpense_hub`.`teams`.`admin_id`     AS `admin_id`,
    `id4885341_xpense_hub`.`teams`.`team_name`    AS `team_name`,
    `id4885341_xpense_hub`.`teams`.`date_created` AS `date_created`
  from (`id4885341_xpense_hub`.`users`
    join `id4885341_xpense_hub`.`teams`
      on ((`id4885341_xpense_hub`.`users`.`team_id` = `id4885341_xpense_hub`.`teams`.`team_id`)));

