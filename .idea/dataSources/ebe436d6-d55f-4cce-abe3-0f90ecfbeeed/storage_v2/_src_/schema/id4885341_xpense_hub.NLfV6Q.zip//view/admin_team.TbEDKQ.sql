create view admin_team as
  select
    `id4885341_xpense_hub`.`admin`.`admin_id`     AS `admin_id`,
    `id4885341_xpense_hub`.`admin`.`full_name`    AS `full_name`,
    `id4885341_xpense_hub`.`admin`.`email`        AS `email`,
    `id4885341_xpense_hub`.`admin`.`password`     AS `password`,
    `id4885341_xpense_hub`.`admin`.`date_created` AS `date_created`,
    `id4885341_xpense_hub`.`admin`.`image_path`   AS `image_path`,
    `id4885341_xpense_hub`.`teams`.`team_id`      AS `team_id`,
    `id4885341_xpense_hub`.`teams`.`team_name`    AS `team_name`
  from (`id4885341_xpense_hub`.`admin`
    join `id4885341_xpense_hub`.`teams`
      on ((`id4885341_xpense_hub`.`admin`.`admin_id` = `id4885341_xpense_hub`.`teams`.`admin_id`)));

