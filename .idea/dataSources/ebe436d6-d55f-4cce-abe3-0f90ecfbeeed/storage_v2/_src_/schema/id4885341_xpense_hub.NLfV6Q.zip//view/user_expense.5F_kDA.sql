create view user_expense as
  select
    `id4885341_xpense_hub`.`users`.`user_id`          AS `user_id`,
    `id4885341_xpense_hub`.`users`.`team_id`          AS `team_id`,
    `id4885341_xpense_hub`.`users`.`full_name`        AS `full_name`,
    `id4885341_xpense_hub`.`users`.`image_path`       AS `image_path`,
    `id4885341_xpense_hub`.`expense`.`expense_id`     AS `expense_id`,
    `id4885341_xpense_hub`.`expense`.`name`           AS `name`,
    `id4885341_xpense_hub`.`expense`.`price`          AS `price`,
    `id4885341_xpense_hub`.`expense`.`description`    AS `description`,
    `id4885341_xpense_hub`.`expense`.`status`         AS `status`,
    `id4885341_xpense_hub`.`expense`.`receipt_status` AS `receipt_status`,
    `id4885341_xpense_hub`.`expense`.`date_created`   AS `date_created`,
    `id4885341_xpense_hub`.`expense`.`date_approved`  AS `date_approved`
  from (`id4885341_xpense_hub`.`users`
    join `id4885341_xpense_hub`.`expense`
      on (((`id4885341_xpense_hub`.`users`.`user_id` = `id4885341_xpense_hub`.`expense`.`user_id`) and
           (`id4885341_xpense_hub`.`users`.`team_id` = `id4885341_xpense_hub`.`expense`.`team_id`))));

